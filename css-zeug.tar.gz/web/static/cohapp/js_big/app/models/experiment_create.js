var app = app || {};

app.ExperimentsModel = Backbone.Model.extend({
	url: app.urls.experiments
});