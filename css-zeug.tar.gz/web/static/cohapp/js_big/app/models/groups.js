var app = app || {};

app.GroupsModel = Backbone.Model.extend({
    url: app.urls.groups
});