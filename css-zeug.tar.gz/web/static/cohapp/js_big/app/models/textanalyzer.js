var app = app || {};

app.TextAnalyzerModel = Backbone.Model.extend({
    url: app.urls.textanalyzer,
});