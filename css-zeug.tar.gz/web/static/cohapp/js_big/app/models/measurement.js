var app = app || {};

app.MeasurementModel = Backbone.Model.extend({
    url: app.urls.measurement
});