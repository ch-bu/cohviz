var app = app || {};

app.MeasurementCollection = Backbone.Collection.extend({
    model: app.MeasurementModel
});